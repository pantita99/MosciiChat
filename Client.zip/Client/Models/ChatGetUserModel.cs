﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client.Models
{
    public class ChatGetUserModel
    {
        public string USERID { get; set; } = null!;
        public string? FullName { get; set; }
        public bool? UserConnected { get; set; }
    }
}

