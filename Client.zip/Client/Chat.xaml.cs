﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.AspNetCore.SignalR.Client;
using Client.Models;

namespace Client
{
    public partial class Chat : Window
    {
        private HubConnection _connection;
        private readonly string url = "https://localhost:7277/chatHub";
        public Chat()
        {
            InitializeComponent();
            InitializeSignalR();
        }
        private async void InitializeSignalR()
        {

            _connection = new HubConnectionBuilder()
                .WithUrl(url)
            .Build();

            _connection.On<string, string>("ReceiveMessage", (user, message) =>
            {
                this.Dispatcher.Invoke(() =>
                {
                    messagesList.Items.Add($"{user}: {message}");
                });
            });


            try
            {
                await _connection.StartAsync();
                //messagesList.Items.Add("Connected to chat");
            }
            catch (Exception ex)
            {
                //messagesList.Items.Add($"Error connecting: {ex.Message}");
            }
            try
            {
                // Invoke GetUserList from the server and update the ListBox
                var users = await _connection.InvokeAsync<List<ChatGetUserModel>>("GetUserList");
                foreach (var user in users)
                {
                    UsersListBox.ItemsSource = users;
                }
                /*this.Dispatcher.Invoke(() =>
                {
                    UsersListBox.ItemsSource = UsersList;
                });*/
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void UserControl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
            {
                Window.GetWindow(this).DragMove();
            }
        }
        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            var window = Window.GetWindow(this);
            if (window != null)
            {
                window.Close();
            }
        }

        private void MinimizeButton_Click(object sender, RoutedEventArgs e)
        {
            var window = Window.GetWindow(this);
            if (window != null)
            {
                window.WindowState = WindowState.Minimized;
            }
        }

        private void MaximizeButton_Click(object sender, RoutedEventArgs e)
        {
            var window = Window.GetWindow(this);
            if (window != null)
            {
                if (window.WindowState == WindowState.Normal)
                {
                    window.WindowState = WindowState.Maximized; // ขยายหน้าต่าง
                }
                else
                {
                    window.WindowState = WindowState.Normal; // คืนค่าขนาดหน้าต่างปกติ
                }
            }
        }
         private async void SendButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                await _connection.InvokeAsync("SendMessage", "wha", MessageTxtBox.Text);
                MessageTxtBox.Clear();


            }
            catch (Exception ex)
            {
                //messagesList.Items.Add($"Error sending message: {ex.Message}");
            }
        }
    }
}
