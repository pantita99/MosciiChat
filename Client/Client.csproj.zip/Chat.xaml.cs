﻿using System.Windows;
using System.Windows.Input;
using Microsoft.AspNetCore.SignalR.Client;
using Client.Models;
using System.Collections.ObjectModel;
using System.Windows.Controls;
using Microsoft.Win32; // สำหรับ OpenFileDialog
using System.IO;
using System.Windows.Threading;
using static MaterialDesignThemes.Wpf.Theme;
using System.Windows.Media;

namespace Client
{
    public partial class Chat : Window
    {
        private HubConnection _connection;
        private DispatcherTimer _statusRefreshTimer;
        private readonly string url = "https://localhost:7277/chatHub";
        public ObservableCollection<ChatGetUserModel> Messages { get; set; }
        public ObservableCollection<ChatGetUserModel> Users { get; set; }
        // เก็บประวัติการแชทของผู้ใช้แต่ละคน
        private Dictionary<string, ObservableCollection<ChatGetUserModel>> chatHistories = new Dictionary<string, ObservableCollection<ChatGetUserModel>>();

        public Chat()
        {
            InitializeComponent();
            InitializeSignalR();

            StartUserStatusRefresh(); // เริ่มการรีเฟรชสถานะผู้ใช้


            Messages = new ObservableCollection<ChatGetUserModel>(); // สร้าง ObservableCollection
            messagesList.ItemsSource = Messages; // เชื่อมต่อ ListBox กับ Messages

            Users = new ObservableCollection<ChatGetUserModel>(); // สร้าง ObservableCollection สำหรับผู้ใช้
            GetUserList.ItemsSource = Users; // เชื่อมต่อ ListBox กับ Users
        }



        private void MessageTextbox_TextChanged(object sender, TextChangedEventArgs e)
        {
            var textBox = sender as System.Windows.Controls.TextBox;

            // คำนวณความสูงของ TextBox ตามจำนวนบรรทัดที่มี

            int lineCount = textBox.LineCount; // จำนวนบรรทัดที่มีอยู่

            // ปรับความสูงของ TextBox

            // เลื่อน ScrollViewer ให้ไปที่ข้อความล่าสุด
            this.ScrollToBottom();
        }

        private void ScrollToBottom()
        {
            // ตรวจสอบว่าข้อมูลใน messagesList ไม่เป็น null
            if (messagesList.Items.Count > 0)
            {
                messagesList.ScrollIntoView(messagesList.Items[^1]);
            }
        }



        private void StartUserStatusRefresh()
        {
            // สร้าง DispatcherTimer ที่จะทำงานทุกๆ 1 นาที
            _statusRefreshTimer = new DispatcherTimer();
            _statusRefreshTimer.Interval = TimeSpan.FromMinutes(1); // ตั้งเวลาเป็น 1 นาที
            _statusRefreshTimer.Tick += OnStatusRefreshTick; // ผูกกับฟังก์ชันที่จะเรียกเมื่อถึงเวลา
            _statusRefreshTimer.Start(); // เริ่มตัวจับเวลา
        }


        private async void OnStatusRefreshTick(object sender, EventArgs e)
        {
            await LoadUsers(); // เรียกฟังก์ชันเพื่อรีเฟรชสถานะผู้ใช้
        }


        private async void InitializeSignalR()
        {
            _connection = new HubConnectionBuilder()
                .WithUrl(url)
                .Build();
            _connection.On<string, byte[]>("ReceiveFile", (fileName, fileBytes) =>
            {
                // เรียกฟังก์ชันเพื่อบันทึกไฟล์ในระบบ
                SaveFile(fileName, fileBytes);
            });



            // กำหนดให้รับข้อความจาก SignalR
            _connection.On<string, string>("ReceiveMessage", (user, message) =>
            {
                // ใช้ Dispatcher เพื่ออัปเดต UI จาก Thread อื่น
                this.Dispatcher.Invoke(() =>
                {
                    Messages.Add(new ChatGetUserModel
                    {
                        SenderId = user,
                        Message = message,
                        Timestamp = DateTime.Now // เพิ่มเวลาในการส่ง
                    });
                });
            });

            try
            {
                // เริ่มเชื่อมต่อกับ SignalR
                await _connection.StartAsync();
            }
            catch (Exception ex)
            {
                // แสดงข้อผิดพลาดในการเชื่อมต่อ
                MessageBox.Show($"Error connecting: {ex.Message}");
            }

            // โหลดรายชื่อผู้ใช้
            await LoadUsers();
        }

        private void SaveFile(string fileName, byte[] fileBytes)
        {
            // กำหนด path สำหรับบันทึกไฟล์
            var savePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), fileName);

            // บันทึกไฟล์ลงในระบบ
            File.WriteAllBytes(savePath, fileBytes);

            // แจ้งผู้ใช้ว่าไฟล์ถูกบันทึกเรียบร้อยแล้ว
            MessageBox.Show($"File {fileName} saved at {savePath}");
        }


        // ฟังก์ชันเพื่อโหลดผู้ใช้และตั้งค่า ItemsSource ของ ListBox
        private async Task LoadUsers()

        {
            try
            {
                if (_connection.State != HubConnectionState.Connected)
                {
                    await _connection.StartAsync();
                }

                var users = await _connection.InvokeAsync<List<ChatGetUserModel>>("GetUserList", "");

                Users.Clear(); // เคลียร์ข้อมูลเก่าก่อนที่จะเพิ่มข้อมูลใหม่

                foreach (var user in users)
                {
                    Users.Add(user); // เพิ่มผู้ใช้เข้าไปใน ObservableCollection
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading user list: {ex.Message}");
            }
        }


        private string selectedUserFullname; // ใช้ FullName แทน UserID

        private void UsersListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (GetUserList.SelectedItem is ChatGetUserModel selectedUser)
            {
                selectedUserFullname = selectedUser.FullName; // เก็บ FullName ของผู้ใช้ที่เลือก

                try
                {
                    LoadChatHistory(selectedUserFullname); // โหลดประวัติการสนทนา
                }
                catch (Exception ex)
                {
                    // จัดการข้อผิดพลาดเมื่อโหลดประวัติการสนทนา
                    MessageBox.Show($"Error loading chat history: {ex.Message}");
                }
            }
            else
            {
                selectedUserFullname = null; // รีเซ็ต selectedUserFullname ถ้าจำเป็น
            }
        }

        private async void LoadChatHistory(string fullName)
        {
            // Ensure the selected user's full name is not null
            if (string.IsNullOrEmpty(fullName))
            {
                return;
            }

            try
            {
                // Assume the logged-in user's FullName is stored somewhere, replace 'myFullName' with the appropriate value
                var myFullName = "YourLoggedInUserName";

                // Get chat history from the server
                var chatHistory = await _connection.InvokeAsync<List<ChatGetUserModel>>("GetChatHistory", myFullName, fullName);

                // Clear the current messages and display the chat history
                Messages.Clear();

                foreach (var message in chatHistory)
                {
                    Messages.Add(message); // Add messages to the observable collection
                }

                // Save the chat history locally (optional)
                chatHistories[fullName] = new ObservableCollection<ChatGetUserModel>(chatHistory);
            }
            catch (Exception ex)
            {
                // Handle errors in loading the chat history
                MessageBox.Show($"Error loading chat history: {ex.Message}");
            }
        }



        private void UserControl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            // ตรวจสอบว่าคลิกด้วยปุ่มซ้ายหรือไม่
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                Window.GetWindow(this).DragMove();
            }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            var window = Window.GetWindow(this);
            window?.Close(); // ใช้ null-conditional operator
        }

        private void MinimizeButton_Click(object sender, RoutedEventArgs e)
        {
            var window = Window.GetWindow(this);
            if (window != null)
            {
                window.WindowState = WindowState.Minimized;
            }
        }

        private void MaximizeButton_Click(object sender, RoutedEventArgs e)
        {
            var window = Window.GetWindow(this);
            if (window != null)
            {
                window.WindowState = (window.WindowState == WindowState.Normal)
                    ? WindowState.Maximized
                    : WindowState.Normal; // ขยายหรือคืนค่าขนาดหน้าต่าง
            }
        }

        private async void SendButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var messageText = messageTextbox.Text; // ข้อความที่ต้องการส่งและลบช่องว่างที่ไม่จำเป็น

                // ตรวจสอบว่า messageText ไม่ใช่ช่องว่างและผู้ใช้ถูกเลือก
                if (!string.IsNullOrWhiteSpace(messageText) && !string.IsNullOrEmpty(selectedUserFullname))
                {
                    // ส่งข้อความไปยังเซิร์ฟเวอร์
                    await _connection.InvokeAsync("SendMessage", selectedUserFullname, messageText);

                    // สร้างข้อความใหม่
                    var newMessage = new ChatGetUserModel
                    {
                        FullName = selectedUserFullname,
                        Message = messageText,
                        Timestamp = DateTime.Now // ใส่เวลาของข้อความ
                    };



                    // บันทึกข้อความใน chatHistories ของผู้ใช้นั้น
                    if (chatHistories.ContainsKey(selectedUserFullname))
                    {
                        chatHistories[selectedUserFullname].Add(newMessage);
                    }
                    else
                    {
                        chatHistories[selectedUserFullname] = new ObservableCollection<ChatGetUserModel> { newMessage };
                    }

                    ScrollToBottom();

                    messageTextbox.Text = string.Empty; // เคลียร์ TextBox
                }
                else if (string.IsNullOrEmpty(selectedUserFullname))
                {
                    MessageBox.Show("Please select a user to send a message."); // แสดงข้อความเมื่อไม่ได้เลือกผู้ใช้
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error sending message: {ex.Message}");
            }
        }

        private async void SendFile_Click(object sender, RoutedEventArgs e)
        {


            try
            {
                // เปิด OpenFileDialog ให้ผู้ใช้เลือกไฟล์
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.Title = "Select a file to send";
                openFileDialog.Filter = "All Files|*.*"; // กำหนดให้สามารถเลือกไฟล์ได้ทุกชนิด
                openFileDialog.Multiselect = false; // ให้เลือกไฟล์ได้เพียงไฟล์เดียว

                if (openFileDialog.ShowDialog() == true)
                {
                    // รับไฟล์ที่เลือกจาก OpenFileDialog
                    string filePath = openFileDialog.FileName;
                    string fileName = Path.GetFileName(filePath);

                    // อ่านเนื้อหาของไฟล์เป็น byte array
                    byte[] fileBytes = File.ReadAllBytes(filePath);

                    // แปลงเป็น Base64 เพื่อส่งเป็นข้อความ (หรือส่งแบบ Stream ตามที่เซิร์ฟเวอร์รองรับ)
                    string base64File = Convert.ToBase64String(fileBytes);

                    // ตรวจสอบว่ามีผู้ใช้ที่เลือกอยู่หรือไม่
                    if (!string.IsNullOrEmpty(selectedUserFullname))
                    {
                        // ส่งไฟล์ไปยังเซิร์ฟเวอร์ผ่าน SignalR (คุณอาจต้องสร้าง hub method สำหรับรับไฟล์)
                        await _connection.InvokeAsync("SendFile", selectedUserFullname, fileName, base64File);

                        // บันทึกประวัติการส่งไฟล์ (สามารถสร้างข้อความแจ้งเตือนในแชทได้)
                        var newFileMessage = new ChatGetUserModel
                        {
                            FullName = selectedUserFullname,
                            Message = $"[Sent a file: {fileName}]",
                            Timestamp = DateTime.Now
                        };

                        // เพิ่มไปยังประวัติการแชท
                        if (chatHistories.ContainsKey(selectedUserFullname))
                        {
                            chatHistories[selectedUserFullname].Add(newFileMessage);
                        }
                        else
                        {
                            chatHistories[selectedUserFullname] = new ObservableCollection<ChatGetUserModel> { newFileMessage };
                        }

                        // อัปเดต UI
                        Messages.Add(newFileMessage);
                    }
                    else
                    {
                        MessageBox.Show("Please select a user to send the file.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error sending file: {ex.Message}");
            }


        }




    }
}