﻿using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using Server.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

public class ChatHub : Hub
{
    private readonly GETUSERBYWHA_Context _context;

    public ChatHub(GETUSERBYWHA_Context context)
    {
        _context = context;
    }

    // ฟังก์ชันสำหรับส่งข้อความ
    public async Task SendMessage(string senderFullName, string receiverFullName, string messageText)
    {
        try
        {
            // ตรวจสอบว่าผู้รับมีในฐานข้อมูล
            var receiverUser = await _context.TB_USER.FirstOrDefaultAsync(u => u.FullName == receiverFullName);

            if (receiverUser == null)
            {
                // แจ้งไปยังผู้ส่งว่าผู้รับไม่ถูกต้อง
                await Clients.Caller.SendAsync("ReceiveMessage", "System", $"User '{receiverFullName}' does not exist.");
                return;
            }

            // บันทึกข้อความลงฐานข้อมูล
            var chatHistory = new TB_CHATHISTRYWHA
            {
                GUID = Guid.NewGuid().ToString(),
                ID = GetCurrentUserId(),
                IDRECIVER = receiverUser.UserID, // ใช้ UserID ของผู้รับ
                MESSAGE = messageText,
                NAME = senderFullName,
                FILENAME = null,
            };

            _context.TB_CHATHISTRYWHA.Add(chatHistory);
            await _context.SaveChangesAsync();

            // ส่งข้อความไปยังผู้รับ
            await Clients.User(receiverUser.UserID.ToString()).SendAsync("ReceiveMessage", senderFullName, messageText);

            // ส่งข้อความกลับไปยังผู้ส่งเพื่อให้ UI อัปเดต
            await Clients.Caller.SendAsync("ReceiveMessage", senderFullName, messageText);
        }
        catch (Exception ex)
        {
            // ส่งข้อความแจ้งข้อผิดพลาดกลับไปยังผู้ส่ง
            await Clients.Caller.SendAsync("ReceiveMessage", "System", $"Error sending message: {ex.Message}");
        }
    }


    private int GetCurrentUserId()
    {
        // สมมติว่าคุณเก็บ User ID ไว้ใน Context
        // ปรับให้ตรงกับวิธีที่คุณเก็บข้อมูลผู้ใช้
        var userId = Context.User?.FindFirst("UserID")?.Value;
        return int.TryParse(userId, out var id) ? id : 0;
    }





    public async Task SaveChatHistory(string senderUserId, string receiverUserId, string message)
    {
        try
        {
            // Validate sender and receiver UserIDs (as string)
            if (string.IsNullOrWhiteSpace(senderUserId) || string.IsNullOrWhiteSpace(receiverUserId))
            {
                throw new ArgumentException("Sender or receiver UserID cannot be null or empty.");
            }

            // Look for sender and receiver by UserID
            var sender = await _context.TB_USER.FirstOrDefaultAsync(u => u.UserID.ToString() == senderUserId);
            var receiver = await _context.TB_USER.FirstOrDefaultAsync(u => u.UserID.ToString() == receiverUserId);

            if (sender == null || receiver == null)
            {
                throw new ArgumentException("Invalid sender or receiver UserID.");
            }

            // Create a new chat history entry
            var chatHistory = new TB_CHATHISTRYWHA
            {
                GUID = Guid.NewGuid().ToString(), // Create a new GUID as string
                ID = sender.UserID,                // Sender ID from TB_USER
                IDRECIVER = receiver.UserID,       // Receiver ID from TB_USER
                MESSAGE = message,
                // Timestamp = DateTime.Now          // Uncomment if you have a Timestamp property in your chat history model
            };

            // Add the chat history to the database
            _context.TB_CHATHISTRYWHA.Add(chatHistory);
            await _context.SaveChangesAsync(); // Save changes to the database
        }
        catch (Exception ex)
        {
            // Log the error (you can use a logging framework like Serilog or NLog)
            Console.WriteLine($"An error occurred while saving chat history: {ex.Message}");
            // You can rethrow the error or handle it as needed
        }
    }




    public async Task<List<ChatGetUserModel>> GetChatHistory(string userId1, string userId2)
    {
        try
        {
            if (string.IsNullOrEmpty(userId1) || string.IsNullOrEmpty(userId2))
            {
                throw new ArgumentException("User IDs cannot be null or empty.");
            }

            // แปลง userId1 และ userId2 เป็น int
            if (!int.TryParse(userId1, out var senderId) || !int.TryParse(userId2, out var receiverId))
            {
                throw new ArgumentException("Invalid user IDs provided.");
            }

            // ดึงประวัติการสนทนาระหว่าง userId1 และ userId2
            var chatHistory = await _context.TB_CHATHISTRYWHA
                .Where(chat => (chat.ID == senderId && chat.IDRECIVER == receiverId) ||
                               (chat.ID == receiverId && chat.IDRECIVER == senderId))
                .ToListAsync();

            // แปลงข้อมูลจาก TB_CHATHISTRYWHA ไปยัง ChatGetUserModel
            var chatMessages = chatHistory.Select(chat => new ChatGetUserModel
            {
                UserID = chat.ID.ToString(),
                FullName = "Your Name", // แทนที่ด้วยชื่อจริงของผู้ส่ง
               
              
            }).ToList();

            return chatMessages;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error in GetChatHistory: {ex.Message}\n{ex.StackTrace}");
            return new List<ChatGetUserModel>(); // คืนค่า List ว่างเปล่าในกรณีที่เกิดข้อผิดพลาด
        }
    }




    public async Task SendFile(string receiverId, string fileName, byte[] fileBytes)
    {
        var userId = Context.UserIdentifier; // Sender ID

        // ตรวจสอบว่า sender ถูกยืนยันตัวตนแล้วหรือไม่
        if (string.IsNullOrEmpty(userId))
        {
            throw new InvalidOperationException("User is not authenticated.");
        }

        // แปลง userId และ receiverId จาก string เป็น int
        if (!int.TryParse(userId, out var senderId))
        {
            throw new ArgumentException("Invalid sender ID.");
        }

        if (!int.TryParse(receiverId, out var receiverIdInt))
        {
            throw new ArgumentException("Invalid receiver ID.");
        }

        // สร้างข้อมูลใหม่สำหรับการส่งไฟล์ในประวัติการสนทนา
        var chatEntry = new TB_CHATHISTRYWHA
        {
            GUID = Guid.NewGuid().ToString(),    // สร้าง GUID ใหม่ในรูปแบบ string
            ID = senderId,                       // รหัสของผู้ส่ง
            IDRECIVER = receiverIdInt,           // รหัสของผู้รับ
            MESSAGE = "[File Sent]",             // ข้อความที่ระบุว่าได้ส่งไฟล์
            NAME = Context.User.Identity.Name,   // ใช้ชื่อของผู้ใช้ที่เข้าสู่ระบบ
            FILENAME = fileName,                 // ชื่อไฟล์ที่ถูกส่ง
                                                 // Timestamp = DateTime.Now           // ถ้ามีฟิลด์ Timestamp ในโมเดล
        };

        // เพิ่มรายการใหม่ในประวัติการสนทนา
        _context.TB_CHATHISTRYWHA.Add(chatEntry);
        await _context.SaveChangesAsync(); // บันทึกการเปลี่ยนแปลงลงฐานข้อมูล

        // ส่งไฟล์และแจ้งเตือนผู้รับ
        await Clients.User(receiverId).SendAsync("ReceiveFile", fileName, fileBytes);
    }


    // ดึงผู้ใช้
    public async Task<List<ChatGetUserModel>> GetUserList(string fullName)
    {
        try
        {
            Console.WriteLine($"Searching for users with name: {fullName}"); // Debugging log

            var users = await _context.TB_USER
                .Where(auth => auth.IsChat == true && auth.FullName.Contains(fullName))
                .Select(auth => new ChatGetUserModel
                {
                    UserID = auth.UserID.ToString(),
                    FullName = auth.FullName,
                    UserConnected = auth.UserConnected,
                })
                .ToListAsync();

            Console.WriteLine($"Found {users.Count} users."); // Debugging log

            return users;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"An error occurred: {ex.Message}");
            return new List<ChatGetUserModel>();
        }
    }

    // แสดงข้อมูลผู้ใช้
    public class ChatGetUserModel
    {
        public string UserID { get; set; } = null!; // รหัสผู้ใช้ที่ไม่ซ้ำ
        public string? FullName { get; set; } // ชื่อเต็มของผู้ใช้
        public bool? UserConnected { get; set; } // สถานะออนไลน์
    }
}
